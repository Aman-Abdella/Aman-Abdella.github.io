AMAN ABDELLA PERSONAL WEBSITE
Upload index.html and style.css directly into the root of Aman-Abdella.github.io.
Then enable GitHub Pages: Settings > Pages > Deploy from branch > main > /(root).
